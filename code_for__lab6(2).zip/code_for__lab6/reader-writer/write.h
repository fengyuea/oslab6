#include"init.h"

void *writer(int *buffer){
    printf ("write ::%d\n", *buffer);
}


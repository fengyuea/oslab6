#include"init.h"

void *reader(int *buffer){
    printf("\nReader Inside..%d\n", *buffer); 
}

